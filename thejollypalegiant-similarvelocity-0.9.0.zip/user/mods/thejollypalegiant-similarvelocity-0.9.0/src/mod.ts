import { DependencyContainer } from "tsyringe";

import { IPostDBLoadMod } from "@spt-aki/models/external/IPostDBLoadMod";
import { DatabaseServer } from "@spt-aki/servers/DatabaseServer";
import { IDatabaseTables } from "@spt-aki/models/spt/server/IDatabaseTables";

class Mod implements IPostDBLoadMod
{
    public postDBLoad(container: DependencyContainer): void 
    {
        // get database from server
        const databaseServer = container.resolve<DatabaseServer>("DatabaseServer");
        

        // Get all the in-memory json found in /assets/database
        const tables: IDatabaseTables = databaseServer.getTables();

        // ---------------------------------------------------------
        // Change the velocity of ammunition

        // Find the ammo by its Id

        // .300 Blackout M62 Tracer
        const a0 = tables.templates.items["619636be6db0f2477964e710"];

        // Set the InitialSpeed (velocity)
        a0._props.InitialSpeed = 768;
        
        // .300 Blackout BCP FMJ
        const a1 = tables.templates.items["5fbe3ffdf8b6a877a729ea82"];

        // Set the InitialSpeed (velocity)
        a1._props.InitialSpeed = 785;
               
        // .300 Blackout AP
        const a2 = tables.templates.items["5fd20ff893a8961fc660a954"];

        // Set the InitialSpeed (velocity)
        a2._props.InitialSpeed = 802;
               
        // .300 Blackout V-Max
        const a3 = tables.templates.items["6196364158ef8c428c287d9f"];

        // Set the InitialSpeed (velocity)
        a3._props.InitialSpeed = 819;
               
        // .300 Blackout CBJ
        const a4 = tables.templates.items["64b8725c4b75259c590fa899"];

        // Set the InitialSpeed (velocity)
        a4._props.InitialSpeed = 836;
        //-------------------------------------------------------------       
        // .366 TKM Geksa
        const a5 = tables.templates.items["59e6658b86f77411d949b250"];

        // Set the InitialSpeed (velocity)
        a5._props.InitialSpeed = 695;
               
        // .366 TKM FMJ
        const a6 = tables.templates.items["59e6542b86f77411dc52a77a"];

        // Set the InitialSpeed (velocity)
        a6._props.InitialSpeed = 720;
               
        // .366 TKM AP-M
        const a7 = tables.templates.items["5f0596629e22f464da6bbdd9"];

        // Set the InitialSpeed (velocity)
        a7._props.InitialSpeed = 745;
        //-------------------------------------------------------------       
        // 4.6x30mm Subsonic SX
        const a8 = tables.templates.items["5ba26844d4351e00334c9475"];

        // Set the InitialSpeed (velocity)
        a8._props.InitialSpeed = 622;
               
        // 4.6x30mm JSP SX
        const a9 = tables.templates.items["64b6979341772715af0f9c39"];

        // Set the InitialSpeed (velocity)
        a9._props.InitialSpeed = 639;

        // 4.6x30mm FMJ SX
        const b0 = tables.templates.items["5ba2678ad4351e44f824b344"];

        // Set the InitialSpeed (velocity)
        b0._props.InitialSpeed = 656;
        //-------------------------------------------------------------
        // 5.7x28mm SB193
        const b1 = tables.templates.items["5cc80f67e4a949035e43bbba"];

        // Set the InitialSpeed (velocity)
        b1._props.InitialSpeed = 673;
               
        // 5.7x28mm SS197SR
        const b2 = tables.templates.items["5cc80f8fe4a949033b0224a2"];

        // Set the InitialSpeed (velocity)
        b2._props.InitialSpeed = 687;
        //-------------------------------------------------------------       
        // 5.45x39mm US gs
        const b3 = tables.templates.items["56dff4ecd2720b5f5a8b4568"];

        // Set the InitialSpeed (velocity)
        b3._props.InitialSpeed = 831;
               
        // 5.45x39mm BS gs
        const b4 = tables.templates.items["56dff026d2720bb8668b4567"];

        // Set the InitialSpeed (velocity)
        b4._props.InitialSpeed = 838;
               
        // 5.45x39mm PS gs
        const b5 = tables.templates.items["56dff3afd2720bba668b4567"];

        // Set the InitialSpeed (velocity)
        b5._props.InitialSpeed = 894;
               
        // 5.45x39mm BP gs
        const b6 = tables.templates.items["56dfef82d2720bbd668b4567"];

        // Set the InitialSpeed (velocity)
        b6._props.InitialSpeed = 901;
               
        // 5.45x39mm PPBS gs
        const b7 = tables.templates.items["5c0d5e4486f77478390952fe"];

        // Set the InitialSpeed (velocity)
        b7._props.InitialSpeed = 908;
        //-------------------------------------------------------------       
        // 5.56x45mm M856
        const b8 = tables.templates.items["59e68f6f86f7746c9f75e846"];

        // Set the InitialSpeed (velocity)
        b8._props.InitialSpeed = 914;
               
        // 5.56x45mm MK 318 MOD
        const b9 = tables.templates.items["60194943740c5d77f6705eea"];

        // Set the InitialSpeed (velocity)
        b9._props.InitialSpeed = 925;
               
        // 5.56x45mm M855
        const c0 = tables.templates.items["54527a984bdc2d4e668b4567"];

        // Set the InitialSpeed (velocity)
        c0._props.InitialSpeed = 936;
        
        // 5.56x45mm Warmageddon
        const c1 = tables.templates.items["5c0d5ae286f7741e46554302"];

        // Set the InitialSpeed (velocity)
        c1._props.InitialSpeed = 947;
               
        // 5.56x45mm MK 255 MOD
        const c2 = tables.templates.items["59e6918f86f7746c9f75e849"];

        // Set the InitialSpeed (velocity)
        c2._props.InitialSpeed = 958;
               
        // 5.56x45mm M856A1
        const c3 = tables.templates.items["59e6906286f7746c9f75e847"];

        // Set the InitialSpeed (velocity)
        c3._props.InitialSpeed = 969;
               
        // 5.56x45mm M855A1
        const c4 = tables.templates.items["54527ac44bdc2d36668b4567"];

        // Set the InitialSpeed (velocity)
        c4._props.InitialSpeed = 980;
               
        // 5.56x45mm HP
        const c5 = tables.templates.items["59e6927d86f77411da468256"];

        // Set the InitialSpeed (velocity)
        c5._props.InitialSpeed = 991;
               
        // 5.56x45mm FMJ
        const c6 = tables.templates.items["59e6920f86f77411d82aa167"];

        // Set the InitialSpeed (velocity)
        c6._props.InitialSpeed = 1002;
        //---------------------------------------------------------------       
        // 7.62x39mm US gzh
        const c7 = tables.templates.items["59e4d24686f7741776641ac7"];

        // Set the InitialSpeed (velocity)
        c7._props.InitialSpeed = 703;
               
        // 7.62x39mm PS gzh
        const c8 = tables.templates.items["5656d7c34bdc2d9d198b4587"];

        // Set the InitialSpeed (velocity)
        c8._props.InitialSpeed = 712;
               
        // 7.62x39mm T-45M1 gzh
        const c9 = tables.templates.items["59e4cf5286f7741778269d8a"];

        // Set the InitialSpeed (velocity)
        c9._props.InitialSpeed = 721;
               
        // 7.62x39mm MAI AP
        const d0 = tables.templates.items["601aa3d2b2bcb34913271e6d"];

        // Set the InitialSpeed (velocity)
        d0._props.InitialSpeed = 739;
        
        // 7.62x39mm PP
        const d1 = tables.templates.items["64b7af434b75259c590fa893"];

        // Set the InitialSpeed (velocity)
        d1._props.InitialSpeed = 748;
               
        // .7.62x39mm HP
        const d2 = tables.templates.items["59e4d3d286f774176a36250a"];
        
        // Set the InitialSpeed (velocity)
        d2._props.InitialSpeed = 757;
        //--------------------------------------------------------------       
        // 7.62x51mm TCW SP
        const d3 = tables.templates.items["5e023e6e34d52a55c3304f71"];

        // Set the InitialSpeed (velocity)
        d3._props.InitialSpeed = 819;
               
        // 7.62x51mm M62 Tracer
        const d4 = tables.templates.items["5a608bf24f39f98ffc77720e"];

        // Set the InitialSpeed (velocity)
        d4._props.InitialSpeed = 820;
        //--------------------------------------------------------------       
        // 7.62x54mm SP BT Tracer
        const d5 = tables.templates.items["64b8f7b5389d7ffd620ccba2"];

        // Set the InitialSpeed (velocity)
        d5._props.InitialSpeed = 791;
               
        // 7.62x54mm FMJ
        const d6 = tables.templates.items["64b8f7968532cf95ee0a0dbf"];

        // Set the InitialSpeed (velocity)
        d6._props.InitialSpeed = 805;
               
        // 7.62x54mm BS gs
        const d7 = tables.templates.items["5e023d48186a883be655e551"];

        // Set the InitialSpeed (velocity)
        d7._props.InitialSpeed = 819;
               
        // 7.62x54mm T-46 gzh
        const d8 = tables.templates.items["5e023cf8186a883be655e54f"];

        // Set the InitialSpeed (velocity)
        d8._props.InitialSpeed = 833;
               
        // 7.62x54mm HP BT Tracer
        const d9 = tables.templates.items["64b8f7c241772715af0f9c3d"];

        // Set the InitialSpeed (velocity)
        d9._props.InitialSpeed = 847;
               
        // 7.62x54mm LPS gzh
        const e0 = tables.templates.items["5887431f2459777e1612938f"];

        // Set the InitialSpeed (velocity)
        e0._props.InitialSpeed = 861;
        //--------------------------------------------------------------
        // 9x18mm PM SP8 gzh
        const e1 = tables.templates.items["5737218f245977612125ba51"];

        // Set the InitialSpeed (velocity)
        e1._props.InitialSpeed = 454;
               
        // 9x18mm PM PSV
        const e2 = tables.templates.items["5737207f24597760ff7b25f2"];

        // Set the InitialSpeed (velocity)
        e2._props.InitialSpeed = 459;
               
        // 9x18mm PM PPE gzh
        const e3 = tables.templates.items["57371b192459775a9f58a5e0"];

        // Set the InitialSpeed (velocity)
        e3._props.InitialSpeed = 464;
               
        // 9x18mm PM PST gzh
        const e4 = tables.templates.items["5737201124597760fc4431f1"];

        // Set the InitialSpeed (velocity)
        e4._props.InitialSpeed = 469;
               
        // 9x18mm PM PPT gzh
        const e5 = tables.templates.items["57371e4124597760ff7b25f1"];

        // Set the InitialSpeed (velocity)
        e5._props.InitialSpeed = 474;
               
        // 9x18mm PM P gzh
        const e6 = tables.templates.items["573719762459775a626ccbc1"];

        // Set the InitialSpeed (velocity)
        e6._props.InitialSpeed = 479;
               
        // 9x18mm PM PRS gs
        const e7 = tables.templates.items["57371eb62459776125652ac1"];

        // Set the InitialSpeed (velocity)
        e7._props.InitialSpeed = 484;
               
        // 9x18mm PM PSO gzh
        const e8 = tables.templates.items["57371f8d24597761006c6a81"];

        // Set the InitialSpeed (velocity)
        e8._props.InitialSpeed = 489;
               
        // 9x18mm PM BZHT gzh
        const e9 = tables.templates.items["573718ba2459775a75491131"];

        // Set the InitialSpeed (velocity)
        e9._props.InitialSpeed = 494;
                                      
        // 9x18mm PM PS gs PPO
        const f0 = tables.templates.items["57371f2b24597761224311f1"];

        // Set the InitialSpeed (velocity)
        f0._props.InitialSpeed = 499;
               
        // 9x18mm PM RG028 gzh
        const f1 = tables.templates.items["573720e02459776143012541"];

        // Set the InitialSpeed (velocity)
        f1._props.InitialSpeed = 504;
               
        // 9x18mm PM SP7 gzh
        const f2 = tables.templates.items["57372140245977611f70ee91"];

        // Set the InitialSpeed (velocity)
        f2._props.InitialSpeed = 509;
               
        // 9x18mm PMM PSTM gzh
        const f3 = tables.templates.items["57371aab2459775a77142f22"];

        // Set the InitialSpeed (velocity)
        f3._props.InitialSpeed = 514;
        //---------------------------------------------------------------       
        // 9x19mm Quakemaker
        const f4 = tables.templates.items["5efb0e16aeb21837e749c7ff"];

        // Set the InitialSpeed (velocity)
        f4._props.InitialSpeed = 504;
               
        // 9x19mm PSO gzh
        const f5 = tables.templates.items["58864a4f2459770fcc257101"];

        // Set the InitialSpeed (velocity)
        f5._props.InitialSpeed = 511;
               
        // 9x19mm T gzh
        const f6 = tables.templates.items["5c3df7d588a4501f290594e5"];

        // Set the InitialSpeed (velocity)
        f6._props.InitialSpeed = 518;
               
        // 9x19mm RIP
        const f7 = tables.templates.items["5c0d56a986f774449d5de529"];

        // Set the InitialSpeed (velocity)
        f7._props.InitialSpeed = 525;
               
        // 9x19mm M882
        const f8 = tables.templates.items["64b7bbb74b75259c590fa897"];

        // Set the InitialSpeed (velocity)
        f8._props.InitialSpeed = 532;
               
        // 9x19mm AP 6.3
        const f9 = tables.templates.items["5c925fa22e221601da359b7b"];

        // Set the InitialSpeed (velocity)
        f9._props.InitialSpeed = 539;
               
        // 9x19mm Luger CCI
        const g0 = tables.templates.items["5a3c16fe86f77452b62de32a"];

        // Set the InitialSpeed (velocity)
        g0._props.InitialSpeed = 546;
               
        // 9x19mm PST gzh
        const g1 = tables.templates.items["56d59d3ad2720bdb418b4577"];

        // Set the InitialSpeed (velocity)
        g1._props.InitialSpeed = 553;
        //--------------------------------------------------------------       
        // 9x21mm 7u4
        const g2 = tables.templates.items["6576f93989f0062e741ba952"];

        // Set the InitialSpeed (velocity)
        g2._props.InitialSpeed = 375;
        //--------------------------------------------------------------       
        // 12/70 Slug Lead
        const g3 = tables.templates.items["58820d1224597753c90aeb13"];

        // Set the InitialSpeed (velocity)
        g3._props.InitialSpeed = 534;
               
        // 12/70 Slug Grizzly 40
        const g4 = tables.templates.items["5d6e6869a4b9361c140bcfde"];

        // Set the InitialSpeed (velocity)
        g4._props.InitialSpeed = 540;
               
        // 12/70 Slug RIP
        const g5 = tables.templates.items["5c0d591486f7744c505b416f"];

        // Set the InitialSpeed (velocity)
        g5._props.InitialSpeed = 546;
               
        // 12/70 Slug "Poleva-3"
        const g6 = tables.templates.items["5d6e6891a4b9361bd473feea"];

        // Set the InitialSpeed (velocity)
        g6._props.InitialSpeed = 552;
               
        // 12/70 Slug Makeshift .50 BMG
        const g7 = tables.templates.items["5d6e68c4a4b9361b93413f79"];

        // Set the InitialSpeed (velocity)
        g7._props.InitialSpeed = 558;
               
        // 12/70 Slug Dual Sabot
        const g8 = tables.templates.items["5d6e68dea4b9361bcc29e659"];

        // Set the InitialSpeed (velocity)
        g8._props.InitialSpeed = 564;
               
        // 12/70 Slug "Poleva-6u"
        const g9 = tables.templates.items["5d6e689ca4b9361bc8618956"];

        // Set the InitialSpeed (velocity)
        g9._props.InitialSpeed = 570;
               
        // 12/70 Slug Copper Sabot HP
        const h0 = tables.templates.items["5d6e68b3a4b9361bca7e50b5"];

        // Set the InitialSpeed (velocity)
        h0._props.InitialSpeed = 576;
               
        // 12/70 Slug FTX Custom Lite
        const h1 = tables.templates.items["5d6e68e6a4b9361c140bcfe0"];

        // Set the InitialSpeed (velocity)
        h1._props.InitialSpeed = 582;
               
        // 12/70 Slug AP-2- Armor-Piercing
        const h2 = tables.templates.items["5d6e68a8a4b9360b6c0d54e2"];

        // Set the InitialSpeed (velocity)
        h2._props.InitialSpeed = 588;
        //---------------------------------------------------------------       
        // 12/70 Piranha
        const h3 = tables.templates.items["64b8ee384b75259c590fa89b"];

        // Set the InitialSpeed (velocity)
        h3._props.InitialSpeed = 385;
               
        // 12/70 Flechette
        const h4 = tables.templates.items["5d6e6911a4b9361bd5780d52"];

        // Set the InitialSpeed (velocity)
        h4._props.InitialSpeed = 394;
               
        // 12/70 5.2mm
        const h5 = tables.templates.items["5d6e6772a4b936088465b17c"];

        // Set the InitialSpeed (velocity)
        h5._props.InitialSpeed = 403;
               
        // 12/70 8.5mm Magnum
        const h6 = tables.templates.items["5d6e6806a4b936088465b17e"];

        // Set the InitialSpeed (velocity)
        h6._props.InitialSpeed = 412;
               
        // 12/70 7mm
        const h7 = tables.templates.items["560d5e524bdc2d25448b4571"];

        // Set the InitialSpeed (velocity)
        h7._props.InitialSpeed = 421;
        //--------------------------------------------------------------       
        // 20/70 5.6mm Buckshot
        const h8 = tables.templates.items["5d6e695fa4b936359b35d852"];

        // Set the InitialSpeed (velocity)
        h8._props.InitialSpeed = 426;
               
        // 20/70 Devastator Slug
        const h9 = tables.templates.items["5d6e6a5fa4b93614ec501745"];

        // Set the InitialSpeed (velocity)
        h9._props.InitialSpeed = 433;
               
        // 20/70 6.2mm Buckshot
        const i0 = tables.templates.items["5d6e69b9a4b9361bc8618958"];

        // Set the InitialSpeed (velocity)
        i0._props.InitialSpeed = 440;
               
        // 20/70 Star Slug
        const i1 = tables.templates.items["5d6e6a05a4b93618084f58d0"];

        // Set the InitialSpeed (velocity)
        i1._props.InitialSpeed = 447;
               
        // 20/70 "Poleva-3" Slug
        const i2 = tables.templates.items["5d6e6a53a4b9361bd473feec"];

        // Set the InitialSpeed (velocity)
        i2._props.InitialSpeed = 454;
               
        // 20/70 7.3mm Buckshot
        const i3 = tables.templates.items["5d6e69c7a4b9360b6c0d54e4"];

        // Set the InitialSpeed (velocity)
        i3._props.InitialSpeed = 461;
               
        // 20/70 "Poleve-6u" Slug
        const i4 = tables.templates.items["5d6e6a42a4b9364f07165f52"];

        // Set the InitialSpeed (velocity)
        i4._props.InitialSpeed = 468;   
        //--------------------------------------------------------------       
        // .357 Magnum FMJ
        const i5 = tables.templates.items["62330b3ed4dc74626d570b95"];

        // Set the InitialSpeed (velocity)
        i5._props.InitialSpeed = 433;
               
        // .357 Magnum JHP
        const i6 = tables.templates.items["62330c18744e5e31df12f516"];

        // Set the InitialSpeed (velocity)
        i6._props.InitialSpeed = 449;
               
        // .357 Magnum SP
        const i7 = tables.templates.items["62330c40bdd19b369e1e53d1"];

        // Set the InitialSpeed (velocity)
        i7._props.InitialSpeed = 465;
        //--------------------------------------------------------------       
        // 23x75mm "Shrapnel-10" Buckshot
        const i8 = tables.templates.items["5e85a9a6eacf8c039e4e2ac1"];

        // Set the InitialSpeed (velocity)
        i8._props.InitialSpeed = 378;
               
        // 23x75mm "Shrapnel-25" Buckshot
        const i9 = tables.templates.items["5f647f31b6238e5dd066e196"];

        // Set the InitialSpeed (velocity)
        i9._props.InitialSpeed = 399;                                

    }
}

module.exports = { mod: new Mod() }